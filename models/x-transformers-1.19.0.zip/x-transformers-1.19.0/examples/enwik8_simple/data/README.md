# Data source

The enwik8 data was downloaded from the Hutter prize page: http://prize.hutter1.net/